package com.kazuno.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF080D19)
private val Panel = Color(0xFF111B2C)
private val Cyan = Color(0xFF63D9F5)
private val Violet = Color(0xFF8C7CFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KazUnoApp() }
    }
}

data class ChatMessage(val text: String, val fromUser: Boolean)

@Composable
fun KazUnoApp() {
    var input by remember { mutableStateOf("") }
    var messages by remember {
        mutableStateOf(listOf(ChatMessage("Привет! Я KazUno — твой персональный ИИ-помощник. Чем займёмся?", false)))
    }
    var showTools by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink, surface = Panel, primary = Cyan,
            secondary = Violet, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Column(
            modifier = Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF101B30), Ink, Color(0xFF080D19)))
            ).padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(46.dp).background(
                        Brush.linearGradient(listOf(Cyan, Violet)), CircleShape
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Ink, modifier = Modifier.size(27.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("KazUno AI", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("ТВОЙ УМНЫЙ ПОМОЩНИК", fontSize = 10.sp, color = Cyan, letterSpacing = 1.5.sp)
                }
                Surface(color = Color(0xFF26314A), shape = RoundedCornerShape(50)) {
                    Text("FREE", color = Cyan, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(22.dp))
            Text("Привет! 👋", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Я могу помочь разобраться почти с чем угодно.", color = Color(0xFFADBBD0), fontSize = 14.sp)
            Spacer(Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureChip("✦ Анализ фото")
                FeatureChip("▶ Кино и аниме")
                FeatureChip("⌘ Помощь")
            }
            Spacer(Modifier.height(18.dp))

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(messages) { message ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
                    ) {
                        Surface(
                            color = if (message.fromUser) Color(0xFF263C59) else Panel,
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.widthIn(max = 310.dp)
                        ) {
                            Text(message.text, modifier = Modifier.padding(14.dp), color = Color.White, fontSize = 15.sp)
                        }
                    }
                }
            }

            if (showTools) {
                Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Инструменты KazUno", fontWeight = FontWeight.Bold)
                        Text("Анализ скриншота • Голосовой режим • Поиск по кадру", color = Color(0xFFB6C6DA), fontSize = 13.sp)
                        Text("В этой стартовой сборке инструменты — интерфейсные заготовки. Подключение ИИ и системных разрешений добавим следующими этапами.", color = Color(0xFF8194AE), fontSize = 11.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(onClick = { showTools = !showTools }) {
                    Icon(Icons.Default.AddCircleOutline, "Инструменты", tint = Cyan)
                }
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Спроси KazUno...") },
                    shape = RoundedCornerShape(24.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Cyan,
                        unfocusedBorderColor = Color(0xFF33445E),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )
                IconButton(
                    onClick = {
                        if (input.isNotBlank()) {
                            messages = messages + ChatMessage(input.trim(), true) +
                                ChatMessage("Сообщение принято. Онлайн-модель ещё не подключена: следующий этап — настроить защищённый AI-сервер и API.", false)
                            input = ""
                        }
                    },
                    modifier = Modifier.background(Brush.linearGradient(listOf(Cyan, Violet)), CircleShape)
                ) {
                    Icon(Icons.Default.ArrowUpward, "Отправить", tint = Ink)
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("KazUno пока работает как стартовый интерфейс • подключение AI впереди", color = Color(0xFF71839D), fontSize = 10.sp)
        }
    }
}

@Composable
private fun FeatureChip(label: String) {
    Surface(color = Color(0xFF1A2940), shape = RoundedCornerShape(50)) {
        Text(label, color = Color(0xFFC8D9EE), modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp), fontSize = 11.sp)
    }
}
